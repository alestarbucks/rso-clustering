# Document clustering using Rat Swarm Optimization
## Alejandro Álvarez Conejo (alejandro.alvarezco@alumnos.upm.es)

This .zip file contains all the exact same files that are also available in the project's (public) repository: https://github.com/alestarbucks/rso-clustering. I **strongly recommend** visiting it as well.

**IMPORTANT:** check the README inside the folder that can be found in the same level as this README. It contains all the information about how to run the code properly. That README also mentions the data that must be downloaded (which was not included in this delivery zip because of their size). Furthermore, all tests have been arranged in Jupyter Notebooks to ease its review.